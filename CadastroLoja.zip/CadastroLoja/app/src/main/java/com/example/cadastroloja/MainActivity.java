package com.example.cadastroloja;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etIdade, etUF, etCidade, etTelefone, etEmail;
    private RadioGroup rgTamanho;
    private CheckBox cbVermelho, cbAzul, cbVerde, cbPreto, cbBranco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etIdade = findViewById(R.id.etIdade);
        etUF = findViewById(R.id.etUF);
        etCidade = findViewById(R.id.etCidade);
        etTelefone = findViewById(R.id.etTelefone);
        etEmail = findViewById(R.id.etEmail);
        rgTamanho = findViewById(R.id.rgTamanho);
        cbVermelho = findViewById(R.id.cbVermelho);
        cbAzul = findViewById(R.id.cbAzul);
        cbVerde = findViewById(R.id.cbVerde);
        cbPreto = findViewById(R.id.cbPreto);
        cbBranco = findViewById(R.id.cbBranco);
        Button btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = etNome.getText().toString();
                String idade = etIdade.getText().toString();
                String uf = etUF.getText().toString();
                String cidade = etCidade.getText().toString();
                String telefone = etTelefone.getText().toString();
                String email = etEmail.getText().toString();

                int selectedTamanhoId = rgTamanho.getCheckedRadioButtonId();
                RadioButton rbTamanhoSelecionado = findViewById(selectedTamanhoId);
                String tamanho = (rbTamanhoSelecionado != null) ? rbTamanhoSelecionado.getText().toString() : "Não selecionado";

                StringBuilder coresSelecionadas = new StringBuilder();
                if (cbVermelho.isChecked()) coresSelecionadas.append("Vermelho ");
                if (cbAzul.isChecked()) coresSelecionadas.append("Azul ");
                if (cbVerde.isChecked()) coresSelecionadas.append("Verde ");
                if (cbPreto.isChecked()) coresSelecionadas.append("Preto ");
                if (cbBranco.isChecked()) coresSelecionadas.append("Branco ");

                String mensagem = "Nome: " + nome + "\nIdade: " + idade + "\nUF: " + uf +
                        "\nCidade: " + cidade + "\nTelefone: " + telefone + "\nEmail: " + email +
                        "\nTamanho: " + tamanho + "\nCores: " + coresSelecionadas.toString();

                Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_LONG).show();
            }
        });
    }
}

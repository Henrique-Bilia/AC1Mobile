package com.example.navegacaoexercicios;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Ex1Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ex1);

        EditText nameInput = findViewById(R.id.nameInput);
        EditText ageInput = findViewById(R.id.ageInput);
        Button checkButton = findViewById(R.id.checkButton);
        TextView resultText = findViewById(R.id.resultText);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String name = nameInput.getText().toString();
                String ageString = ageInput.getText().toString();

                if (!name.isEmpty() && !ageString.isEmpty()) {
                    try {
                        int age = Integer.parseInt(ageString);
                        if (age >= 18) {
                            resultText.setText(name + ", você é maior de idade!");
                        } else {
                            resultText.setText(name + ", você não é maior de idade.");
                        }
                    } catch (NumberFormatException e) {
                        resultText.setText("Por favor, insira uma idade válida.");
                    }
                } else {
                    resultText.setText("Por favor, preencha os campos corretamente.");
                }
            }
        });
    }
}

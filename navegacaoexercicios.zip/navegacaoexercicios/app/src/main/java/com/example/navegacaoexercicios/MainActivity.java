package com.example.navegacaoexercicios;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //

        Button btnExercicio1 = findViewById(R.id.btnEx1Activity);
        Button btnExercicio2 = findViewById(R.id.btnEx2Activity);
        Button btnExercicio3 = findViewById(R.id.btnEx3Activity);
        Button btnExercicio4 = findViewById(R.id.btnEx4Activity);
        Button btnExercicio5 = findViewById(R.id.btnEx5Activity);


        btnExercicio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Ex1Activity.class);
                startActivity(intent);
            }
        });

        btnExercicio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Ex2Activity.class);
                startActivity(intent);
            }
        });

        btnExercicio3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Ex3Activity.class);
                startActivity(intent);
            }
        });

        btnExercicio4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Ex4Activity.class);
                startActivity(intent);
            }
        });

        btnExercicio5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Ex5Activity.class);
                startActivity(intent);
            }
        });
    }
}
